
const dotenv = require("dotenv");
const mongoose = require('mongoose');
const express = require('express');
const app = express();

//provide path of config and conn file
dotenv.config({path: './config.env'});

require('./db/conn');
//const Form = required('./model/userSchema');

//since we are sending data in json from postman we were
//getting undefined error so we are using middle and use 
//the below fn to convert the data coming as express.json into object
app.use(express.json());

//To link the router files 
app.use(require('./router/auth'));

const PORT = process.env.PORT || 5000;



//Middleware

const middleware = (req, res, next)  => {
    console.log('its middleware');
}

// Define route handlers
// formpage route
//app.get('/', (req, res) => {
   // res.send('Home Page');
//});

app.get('/forms',(req, res) => {
    res.send('Forms');
    next();
});

//submittedforms
app.get('/submittedforms', middleware ,(req, res) => {
    res.send('Submitted Forms');
    next();
});

//Start the server

app.listen(PORT, () => {
    console.log('Connected port ${PORT}');    
});