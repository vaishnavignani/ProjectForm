import React from 'react'
import { Routes, Route} from "react-router-dom";
import "./App.css";
import Navbar from "./Components/Navbar";
import Home from "./Components/Home";
import FormRegistration from "./Components/FormRegistration";
import MyForms from "./Components/MyForms";


function App() {
  return (
    <>
      <Navbar /> 
        <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/FormRegistration" element={<FormRegistration />} />
            <Route path="/MyForms" element={<MyForms />} />
        </Routes>     
    </>
        
  );
};

export default App;
