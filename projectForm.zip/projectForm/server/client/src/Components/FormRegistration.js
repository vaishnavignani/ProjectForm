import React, { useState } from "react";
import signpic from "../images/logo2.png";

const FormRegistration = () => {

  
  const [user, setUser] = useState({
    name: "",
    dateofbirth: "",
    email: "",
    phone: "",
  });

  const [errors, setErrors] = useState({});

  const handleInputs = (e) => {
    const { name, value } = e.target;

    setUser({ ...user, [name]: value });
  };

  const PostData = async (e) => {
      e.preventDefault();

      const {name, dateofbirth, email, phone} = user;

     const res = await fetch("/forms", {
        method : "POST",
        headers: {
          "Content-Type" : "application/json"
        },
        body: JSON.stringify({
          name, dateofbirth, email, phone
        })
     });

     const data = await res.json();

     if (data.status === 422 || ! data ) {
        window.alert("Form Submission Failed");
        console.log("Form Submission Failed");
     } else {
        window.alert('Form Submitted Successfully');
        console.log('Form Submitted Successfully');   
     }


  }

  const validateForm = () => {
    let errors = {};

    if (!user.name.trim()) {
      errors.name = "Name must have a value";
    }

    if (!user.dateofbirth) {
      errors.dateofbirth = "Date of birth must have a value";
    }

    // Age validation
  const today = new Date();
  const birthDate = new Date(user.dateofbirth);
  const age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  if (age < 18) {
    errors.dateofbirth = "Age must be greater than 18";
  }

    if (!user.email.trim()) {
      errors.email = "Email must have a value";
    } else if (!/\S+@\S+\.\S+/.test(user.email)) {
      errors.email = "Invalid email address - must be within validation rule";
    }

    if (!user.phone.trim()) {
      errors.phone = "Phone number must have a value";
    }

    setErrors(errors);

    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      // Form is valid, submit the data or perform further actions
      console.log("Form submitted");
    } else {
      // Form is invalid, display error messages or perform other actions
      console.log("Form validation failed");
    }
  };

  return (
    <>
      <section className="signup">
        <div className="container mt-5">
          <div className="signup-content">
            <div className="signup-form">
              <h2 className="form-title">Form Registration </h2>
              <form method = "POST" className="register-form" id="register-form" onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="name">
                    <i className="zmdi zmdi-account material-icons-name"></i>
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    autoComplete="off"
                    value={user.name}
                    onChange={handleInputs}
                    placeholder="Name"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>

                <div className="form-group">
                  <label htmlFor="dateofbirth">
                    <i className="zmdi zmdi-calendar"></i>
                  </label>
                  <input
                    type="date"
                    name="dateofbirth"
                    id="dateofbirth"
                    autoComplete="off"
                    value={user.dateofbirth}
                    onChange={handleInputs}
                    placeholder="Date Of Birth"
                  />
                  {errors.dateofbirth && <span className="error-message">{errors.dateofbirth}</span>}
                </div>

                <div className="form-group">
                  <label htmlFor="email">
                    <i className="zmdi zmdi-email material-icons-name"></i>
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    autoComplete="off"
                    value={user.email}
                    onChange={handleInputs}
                    placeholder="Email"
                  />
                  {errors.email && <span className="error-message">{errors.email}</span>}
                </div>

                <div className="form-group">
                  <label htmlFor="phone">
                    <i className="zmdi zmdi-phone-in-talk material-icons-name"></i>
                  </label>
                  <input
                    type="text"
                    name="phone"
                    id="phone"
                    autoComplete="off"
                    value={user.phone}
                    onChange={handleInputs}
                    placeholder="Phone"
                  />
                  {errors.phone && <span className="error-message">{errors.phone}</span>}
                </div>

                <div className="form-group form button">
                  <input type="submit" name="signup" id="signup" className="form-submit" value="Submit" onClick={PostData} />
                </div>
              </form>
            </div>
            <div className="signup-image">
              <figure>
                <img src={signpic} alt="registration pic" />
              </figure>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default FormRegistration;
