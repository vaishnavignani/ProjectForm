import React from 'react'
import homepic from "../images/logo3.png"

const Home = () => {
  return (
    <div>
     <h1 className="main">Welcome To Project Form</h1>  
    </div>
  )
}

export default Home
