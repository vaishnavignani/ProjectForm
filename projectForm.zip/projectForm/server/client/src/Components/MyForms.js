import React from 'react'

const MyForms = () => {
  return (
    <h1 className="myf">Coming Soon !!!</h1>
  )
}

export default MyForms
