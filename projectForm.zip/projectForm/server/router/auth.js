
const express = require('express');
const router = express.Router(); // it is all ability that we had with express to get post and all

require('../db/conn');
const Form = require("../model/userSchema");

router.get('/', (req, res)=> {
    res.send('Hello from server router: form')
})


//using promises
/*router.post('/form', (req, res) => {

    const {name, dob, email, phone} =  req.body;
    if(!phone) {
        return res.status(422).json({error: "PhoneNumber cannot be empty"});
    }

    Form.findOne({phone:phone})
        .then((FormExist) => {
             if(FormExist) {
                return res.status(422).json({error: "Form with this phone number already exist"})
        }

        const form = new Form({name, dob, email, phone});

        form.save().then(() => {
            res.status(201).json({message: "Form Registered Successfully"});
        }).catch((err) => res.status(500).json({error: "Form Registration Failed"}));
    }).catch((err) => {console.log(err);});
   
})*/

//Async

router.post('/forms', async (req, res) => {

    const {name, dob, email, phone} =  req.body;

    if(!phone) {
        return res.status(400).json({error: "Phone Number cannot be empty"});  
    }

    if(! /^\d{10}$/.test(phone)){
        return res.status(400).json({ error: 'Invalid Phone Number'});
    }

    try{
        const existingForm = await Form.findOne({phone,email});

        if(existingForm) {
            return res.status(400).json({error: 'Form already exist with this details'});
        }
       
        const form = new Form({name, dob, email, phone});
        await form.save();    
        return res.status(201).json({message: "Form Registered Successfully"});
    } catch (error) {
        console.log(error);
    } 
})

module.exports = router;